
网址：http://zhengruioi.com/problem/2349

题目：#2349. noip十连测day2-t1

题面: 2349.md

题解: tutorial.pdf

下发文件: 2340.zip

最快提交: /faster

最短提交: /smaller

非满分提交: /other
