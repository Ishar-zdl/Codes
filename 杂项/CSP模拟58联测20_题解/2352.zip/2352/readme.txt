
网址：http://zhengruioi.com/problem/2352

题目：#2352. noip十连测day2-t4

题面: 2352.md

题解: tutorial.pdf

下发文件: 2340.zip

最快提交: /faster

最短提交: /smaller

非满分提交: /other
