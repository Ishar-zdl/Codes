/*
If the radiance of a thousand suns were to burst into the sky?
...that would be like the splendor of the mighty one.
*/
#pragma GCC optimize("Ofast,no-stack-protector")
#pragma GCC target("avx2,fma")
#include "testlib.h"
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#define LL long long
#define ULL unsigned long long
using namespace std;
const int MAXN = 2e5 + 5;
const int MAXM = 30;

template <typename T>
inline void read(T& x) {
  x = 0; int f = 1; char c = getchar(); while (c < '0' || c > '9') { if (c == '-') f = -f; c = getchar(); }
  while (c >= '0' && c <= '9') { x = (x << 3) + (x << 1) + (c ^ 48), c = getchar(); } x *= f;
}
template <typename T, typename... Args>
inline void read (T &x, Args&... Arg) { read (x), read (Arg...); }
template <typename T>
inline T Abs(T x) { return x < 0 ? -x : x; }
template <typename T>
inline T Max(T x, T y) { return x > y ? x : y; }
template <typename T>
inline T Min(T x, T y) { return x < y ? x : y; }

int n, m, t, dep[MAXN], fa[MAXN][MAXM];
vector<int> G[MAXN];
inline void addedge(int u, int v) { G[u].push_back(v), G[v].push_back(u); }

inline void dfs(int u, int fath) {
  dep[u] = dep[fath] + 1, fa[u][0] = fath;
  for (int i = 1; i <= t; i++) fa[u][i] = fa[fa[u][i - 1]][i - 1];
  for (int v : G[u]) if (v != fath) dfs(v, u);
}
inline int lca(int x, int y) {
  if (dep[x] > dep[y]) swap(x, y);
  for (int i = t; i >= 0; i--) if (dep[fa[y][i]] >= dep[x]) y = fa[y][i];
  if (x == y) return x;
  for (int i = t; i >= 0; i--) if (fa[y][i] != fa[x][i]) y = fa[y][i], x = fa[x][i];
  return fa[x][0];
}
inline int dist(int u, int v) { return dep[u] + dep[v] - 2 * dep[lca(u, v)]; }

int main(int argc, char* argv[]) {

  registerLemonChecker(argc, argv);

  n = inf.readInt(), t = log2(n);
  for (int i = 1, u, v; i < n; i++) u = inf.readInt(), v = inf.readInt(), addedge(u, v);
  dfs(1, 0);

  m = inf.readInt();
  for (int cas = 1, u, d; cas <= m; cas++) {
    u = inf.readInt(), d = inf.readInt();
    int res = ans.readInt();
    int now = ouf.readInt();
    if (res == -1) {
      if (now != -1) quitf(_wa, "On case #%d (u, d) = (%d, %d)\nThere is no block satisfied.", cas, u, d);
      else continue;
    }
    if (now == -1) {
      quitf(_wa, "On case #%d (u, d) = (%d, %d)\nThe block v = %d is satisfied.\nBut u do not find it.", cas, u, d, res);
    }
    if (dist(u, now) != d) quitf(_wa, "On case #%d (u, d) = (%d, %d)\nThe block v = %d is not satisfied.", cas, u, d, now);
    else continue;
  }
  quitf(_ok, "All the answers are satisfied.");

  return 0;
}