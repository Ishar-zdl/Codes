export const lightbox = {
    css: 'https://unpkg.com/lightbox2@2.11.1/dist/css/lightbox.min.css',
    js: 'https://unpkg.com/lightbox2@2.11.1/dist/js/lightbox.min.js',
};