module.exports = {
    plugins: [
        require('autoprefixer')
    ]
}